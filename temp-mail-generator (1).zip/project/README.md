# TempMail — Disposable Email Service

A real, working disposable-email website: React/Vite frontend + a Cloudflare Worker backend
that **actually receives email** for domains you own (via Cloudflare Email Routing), stores
messages in D1 (SQL) and attachments in R2, and auto-expires everything after a short TTL.

This replaces an earlier version that proxied unofficial mail.tm/Guerrilla Mail endpoints.
That approach is why it kept getting blocked — it depended on scraping someone else's free
service instead of running real mail infrastructure. This version owns the whole pipeline.

---

## How it works

```
Sender ──> MX record ──> Cloudflare Email Routing ──> this Worker's email() handler
                                                              │
                                                              ▼
                                                     parses MIME, writes to D1,
                                                     stores attachments in R2
                                                              │
Browser ──> GET /api/messages ──> Worker fetch() handler ────┘
Browser ──> everything else ──> static frontend (built by Vite, served from /dist)
```

No account creation, no tokens, no third-party API calls. Any address
`anything@yourdomain.com` is instantly a valid inbox because the domain is a catch-all.

---

## Prerequisites

- A domain you own, with its nameservers pointed at Cloudflare (Cloudflare's free plan is fine)
- Node.js 18+
- A free [Cloudflare account](https://dash.cloudflare.com/sign-up)

## 1. Install dependencies

```bash
npm install
npm install -g wrangler   # or use `npx wrangler ...` for every command below
wrangler login
```

## 2. Create the D1 database and R2 bucket

```bash
npm run db:create
# Copy the printed database_id into wrangler.toml under [[d1_databases]] -> database_id

npm run r2:create

npm run db:migrate:remote   # applies worker/schema.sql to your live D1 database
npm run db:migrate:local    # (optional) same, for local `wrangler dev` testing
```

## 3. Configure your domain(s)

Edit `wrangler.toml`:

```toml
[vars]
ALLOWED_DOMAINS = "yourdomain.com,another-domain.com"
MAILBOX_TTL_MINUTES = "10"
```

Only list domains you actually own and will configure below — this list is also what
gets shown to visitors as available domains.

## 4. Turn on Email Routing and point it at this Worker

In the Cloudflare dashboard, for each domain in `ALLOWED_DOMAINS`:

1. **Email → Email Routing → Enable.** Cloudflare auto-adds the required MX/TXT records
   (since your domain is already on Cloudflare's nameservers, this is one click).
2. **Routing rules → Catch-all address → Send to a Worker → select this Worker** (deploy
   it first, step 5, so it shows up in the list).

That's it — every address at that domain now delivers into your Worker's `email()` handler.

## 5. Build and deploy

```bash
npm run worker:deploy
```

This runs `vite build` then `wrangler deploy`, which uploads both the static frontend
and the Worker in one shot. Wrangler prints your `*.workers.dev` URL — visit it to confirm
the site loads and `/api/domains` returns your domain list. (Optional: add a custom domain
for the site itself under **Workers & Pages → your worker → Settings → Domains & Routes**.)

## 6. Test it end-to-end

1. Open your deployed URL — it should generate an address like `kayon1234@yourdomain.com`.
2. From any real email account, send a message to that exact address.
3. Within a few seconds it should appear in the inbox list (the frontend polls
   `/api/messages` every 8–12s). Open it to confirm body + attachments render.
4. Try `curl https://your-worker-url/api/health` — should return `{"status":"ok",...}`.

**Local dev caveat:** `wrangler dev` can run the API locally, but Cloudflare Email Routing
only delivers to *deployed* Workers — you can't receive real test email against localhost.
For local iteration on the API/DB logic, run `npm run worker:dev` (terminal 1) and
`npm run dev` (terminal 2, proxies `/api` to the Worker per `vite.config.ts`), and insert
test rows directly:

```bash
npx wrangler d1 execute tempmail-db --local --command \
  "INSERT INTO messages (id, mailbox, from_address, subject, text_body, html_body, received_at, expires_at) \
   VALUES ('test1', 'foo@yourdomain.com', 'sender@example.com', 'Hello', 'hi there', '', $(date +%s000), $(($(date +%s000)+600000)))"
```

Then visit the local frontend with that address to confirm it renders.

---

## Hosting cost at scale (up to ~1M visitors/month)

Everything above runs on **Cloudflare's free plan**, with real numbers so you can judge
where the ceiling actually is:

| Resource | Free tier | 1M visitors/month reality |
|---|---|---|
| Workers requests | 100,000/day (~3M/month) | Comfortable, assuming a few requests per visit |
| Workers CPU time | 10ms/request free tier limit | Fine for this workload (simple DB reads/writes) |
| Email Routing | Unlimited, free | No cap tied to volume |
| D1 (database) | 5GB storage, 25M rows read/day, **50k rows written/day** | Storage is fine. Row *writes* are the one real ceiling — each inbound email is ~1-2 writes (message + attachments), so this comfortably covers tens of thousands of emails/day, but a viral spike sending hundreds of thousands of emails/day could hit it. The TTL cleanup job also deletes rows, which count as writes |
| R2 (attachments) | 10GB storage, no egress fees | Auto-cleanup (the cron job) keeps this from growing unbounded |

**Bottom line:** static traffic and normal usage patterns stay entirely free. The one
knob to watch is D1 write volume if the *inbound email* rate (not just visitor count) gets
very high — if you ever approach that, Cloudflare's paid D1 tier is $5/month base plus
usage, not a wall you hit suddenly. I'd treat "free forever no matter what" as unrealistic
marketing from any provider, but this architecture keeps costs at effectively zero for
realistic disposable-mail usage and only scales to small, predictable paid tiers beyond that.

**One more free-tier note:** Cloudflare's dashboard **Rate Limiting Rules** (available on
the free plan, a handful of rules included) are worth configuring on `/api/*` in addition
to the basic app-level limiter already in `worker/src/index.ts` — the dashboard rules catch
abuse at the edge before it even reaches your Worker.

---

## Project structure

```
src/               React/Vite frontend (unchanged UI, rewired to the new API)
worker/src/        Cloudflare Worker: HTTP API, email receiver, scheduled cleanup
worker/schema.sql  D1 database schema
wrangler.toml      Worker config: D1/R2 bindings, allowed domains, cron trigger
vite.config.ts     Dev server + proxy to `wrangler dev` for local testing
```

## What changed from the previous version

- Removed `server.ts` (Express) and all mail.tm / Guerrilla Mail scraping — that's what
  was getting blocked and could never scale legitimately.
- Removed the Firestore-as-backup-cache layer — no longer needed since D1 *is* the
  source of truth and messages don't need a second, less reliable copy.
- Frontend (`src/App.tsx`) is otherwise the same UI, just talking to the new endpoints:
  `/api/domains`, `/api/messages`, `/api/message`, `/api/download-attachment`,
  `/api/contact`, `/api/indexnow` — all now real, all served by the one Worker.
