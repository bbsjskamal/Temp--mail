-- Cloudflare D1 schema for the temp-mail backend.
-- Apply with: npx wrangler d1 execute tempmail-db --file=./worker/schema.sql (add --remote for production)

CREATE TABLE IF NOT EXISTS messages (
  id TEXT PRIMARY KEY,              -- uuid
  mailbox TEXT NOT NULL,            -- full address, lowercase, e.g. "kayon1234@yourdomain.com"
  from_address TEXT,
  from_name TEXT,
  subject TEXT,
  text_body TEXT,
  html_body TEXT,
  received_at INTEGER NOT NULL,     -- unix ms
  expires_at INTEGER NOT NULL       -- unix ms, when this row (and its attachments) should be purged
);

CREATE INDEX IF NOT EXISTS idx_messages_mailbox ON messages (mailbox);
CREATE INDEX IF NOT EXISTS idx_messages_expires ON messages (expires_at);

CREATE TABLE IF NOT EXISTS attachments (
  id TEXT PRIMARY KEY,              -- uuid
  message_id TEXT NOT NULL REFERENCES messages(id),
  filename TEXT,
  content_type TEXT,
  size INTEGER,
  r2_key TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_attachments_message ON attachments (message_id);

-- Simple fixed-window rate-limit counters (see worker/src/index.ts -> rateLimited()).
CREATE TABLE IF NOT EXISTS rate_limits (
  key TEXT PRIMARY KEY,
  count INTEGER NOT NULL DEFAULT 0
);

-- Contact Us form submissions (kept for a fixed period; not tied to any mailbox TTL).
CREATE TABLE IF NOT EXISTS contact_submissions (
  id TEXT PRIMARY KEY,
  name TEXT,
  email TEXT,
  subject TEXT,
  message TEXT,
  submitted_at INTEGER NOT NULL
);
