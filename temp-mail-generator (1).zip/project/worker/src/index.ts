import PostalMime from "postal-mime";

export interface Env {
  DB: D1Database;
  ATTACHMENTS: R2Bucket;
  ASSETS: { fetch: (req: Request) => Promise<Response> };
  ALLOWED_DOMAINS: string;
  MAILBOX_TTL_MINUTES: string;
}

function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
  };
}

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", ...corsHeaders() },
  });
}

function allowedDomains(env: Env): string[] {
  return env.ALLOWED_DOMAINS.split(",").map((d) => d.trim().toLowerCase()).filter(Boolean);
}

function isValidMailbox(address: string, env: Env): boolean {
  const at = address.lastIndexOf("@");
  if (at <= 0) return false;
  const local = address.slice(0, at);
  const domain = address.slice(at + 1).toLowerCase();
  // Local part: letters/numbers/dot/dash/underscore only, reasonable length.
  if (!/^[a-z0-9._-]{1,64}$/i.test(local)) return false;
  return allowedDomains(env).includes(domain);
}

// ---- very small fixed-window rate limiter, backed by D1 ----
// Good enough as an app-level backstop; for real abuse protection at scale,
// also configure Cloudflare's dashboard Rate Limiting Rules (free tier includes some).
async function rateLimited(env: Env, ip: string, bucket: string, limit: number, windowSeconds: number): Promise<boolean> {
  const windowStart = Math.floor(Date.now() / 1000 / windowSeconds) * windowSeconds;
  const key = `${bucket}:${ip}:${windowStart}`;
  try {
    await env.DB.prepare(
      `INSERT INTO rate_limits (key, count) VALUES (?, 1)
       ON CONFLICT(key) DO UPDATE SET count = count + 1`
    ).bind(key).run();
    const row = await env.DB.prepare(`SELECT count FROM rate_limits WHERE key = ?`).bind(key).first<{ count: number }>();
    return (row?.count ?? 0) > limit;
  } catch {
    return false; // fail open rather than break the app if the limiter table has an issue
  }
}

function clientIp(req: Request): string {
  return req.headers.get("cf-connecting-ip") || "unknown";
}

async function handleApi(req: Request, env: Env, url: URL): Promise<Response> {
  const ip = clientIp(req);

  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders() });
  }

  // GET /api/domains
  if (url.pathname === "/api/domains" && req.method === "GET") {
    return json(allowedDomains(env));
  }

  // GET /api/messages?address=foo@yourdomain.com
  if (url.pathname === "/api/messages" && req.method === "GET") {
    const address = (url.searchParams.get("address") || "").toLowerCase();
    if (!isValidMailbox(address, env)) return json({ error: "Invalid or unsupported address" }, 400);
    if (await rateLimited(env, ip, "messages", 120, 60)) {
      return json({ error: "Too many requests. Please slow down." }, 429);
    }

    const { results } = await env.DB.prepare(
      `SELECT id, from_address, from_name, subject, received_at
       FROM messages WHERE mailbox = ? AND expires_at > ?
       ORDER BY received_at DESC LIMIT 100`
    ).bind(address, Date.now()).all();

    return json(results ?? []);
  }

  // GET /api/message?id=...&address=foo@yourdomain.com
  if (url.pathname === "/api/message" && req.method === "GET") {
    const id = url.searchParams.get("id") || "";
    const address = (url.searchParams.get("address") || "").toLowerCase();
    if (!id || !isValidMailbox(address, env)) return json({ error: "Invalid request" }, 400);

    const msg = await env.DB.prepare(
      `SELECT * FROM messages WHERE id = ? AND mailbox = ? AND expires_at > ?`
    ).bind(id, address, Date.now()).first();
    if (!msg) return json({ error: "Not found or expired" }, 404);

    const { results: attachments } = await env.DB.prepare(
      `SELECT id, filename, content_type, size FROM attachments WHERE message_id = ?`
    ).bind(id).all();

    return json({ ...msg, attachments: attachments ?? [] });
  }

  // GET /api/download-attachment?id=...
  if (url.pathname === "/api/download-attachment" && req.method === "GET") {
    const id = url.searchParams.get("id") || "";
    const attachment = await env.DB.prepare(
      `SELECT * FROM attachments WHERE id = ?`
    ).bind(id).first<{ r2_key: string; filename: string; content_type: string }>();
    if (!attachment) return json({ error: "Not found" }, 404);

    const obj = await env.ATTACHMENTS.get(attachment.r2_key);
    if (!obj) return json({ error: "Attachment data missing" }, 404);

    return new Response(obj.body, {
      headers: {
        "Content-Type": attachment.content_type || "application/octet-stream",
        "Content-Disposition": `attachment; filename="${(attachment.filename || "file").replace(/"/g, "")}"`,
        ...corsHeaders(),
      },
    });
  }

  // POST /api/contact
  if (url.pathname === "/api/contact" && req.method === "POST") {
    if (await rateLimited(env, ip, "contact", 10, 3600)) {
      return json({ error: "Too many submissions. Please try again later." }, 429);
    }
    let body: { name?: string; email?: string; subject?: string; message?: string };
    try {
      body = await req.json();
    } catch {
      return json({ error: "Invalid JSON body" }, 400);
    }
    if (!body.email || !body.message) return json({ error: "Missing required fields" }, 400);

    await env.DB.prepare(
      `INSERT INTO contact_submissions (id, name, email, subject, message, submitted_at) VALUES (?, ?, ?, ?, ?, ?)`
    ).bind(
      crypto.randomUUID(),
      (body.name ?? "").slice(0, 200),
      body.email.slice(0, 200),
      (body.subject ?? "").slice(0, 200),
      body.message.slice(0, 5000),
      Date.now()
    ).run();

    return json({ status: "received" });
  }

  // POST /api/indexnow — proxies to the IndexNow API (avoids CORS issues calling it from the browser)
  if (url.pathname === "/api/indexnow" && req.method === "POST") {
    let body: { host?: string; key?: string; keyLocation?: string; urlList?: string[] };
    try {
      body = await req.json();
    } catch {
      return json({ message: "Invalid JSON body" }, 400);
    }
    if (!body.host || !body.key || !body.urlList?.length) {
      return json({ message: "Missing required fields" }, 400);
    }
    const upstream = await fetch("https://api.indexnow.org/indexnow", {
      method: "POST",
      headers: { "Content-Type": "application/json; charset=utf-8" },
      body: JSON.stringify({
        host: body.host,
        key: body.key,
        keyLocation: body.keyLocation,
        urlList: body.urlList,
      }),
    });
    if (upstream.ok) {
      return json({ message: `Submitted ${body.urlList.length} URL(s) to IndexNow.` });
    }
    const text = await upstream.text().catch(() => "");
    return json({ message: `IndexNow rejected the submission (${upstream.status})`, data: text }, upstream.status);
  }

  // GET /api/health
  if (url.pathname === "/api/health" && req.method === "GET") {
    return json({ status: "ok", timestamp: new Date().toISOString(), domains: allowedDomains(env) });
  }

  return json({ error: "Not found" }, 404);
}

export default {
  async fetch(req: Request, env: Env): Promise<Response> {
    const url = new URL(req.url);
    if (url.pathname.startsWith("/api/")) {
      return handleApi(req, env, url);
    }
    // Everything else: serve the built frontend (static assets binding).
    return env.ASSETS.fetch(req);
  },

  // Inbound email handler — wired up via Cloudflare Email Routing in the dashboard
  // (Email → Email Routing → Routing rules → "Send to a Worker" → this worker).
  async email(message: ForwardableEmailMessage, env: Env): Promise<void> {
    const mailbox = message.to.toLowerCase();
    if (!isValidMailbox(mailbox, env)) {
      message.setReject("Mailbox not accepted");
      return;
    }

    const raw = new Response(message.raw);
    const buffer = await raw.arrayBuffer();
    const parsed = await PostalMime.parse(buffer);

    const id = crypto.randomUUID();
    const now = Date.now();
    const ttlMs = Number(env.MAILBOX_TTL_MINUTES || "10") * 60 * 1000;
    const expiresAt = now + ttlMs;

    await env.DB.prepare(
      `INSERT INTO messages (id, mailbox, from_address, from_name, subject, text_body, html_body, received_at, expires_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).bind(
      id,
      mailbox,
      parsed.from?.address ?? "",
      parsed.from?.name ?? "",
      parsed.subject ?? "(no subject)",
      parsed.text ?? "",
      parsed.html ?? "",
      now,
      expiresAt
    ).run();

    for (const att of parsed.attachments ?? []) {
      const attId = crypto.randomUUID();
      const r2Key = `${id}/${attId}`;
      const bytes = att.content instanceof ArrayBuffer ? att.content : (att.content as any)?.buffer;
      if (bytes) {
        await env.ATTACHMENTS.put(r2Key, bytes, {
          httpMetadata: { contentType: att.mimeType || "application/octet-stream" },
        });
        await env.DB.prepare(
          `INSERT INTO attachments (id, message_id, filename, content_type, size, r2_key)
           VALUES (?, ?, ?, ?, ?, ?)`
        ).bind(attId, id, att.filename ?? "attachment", att.mimeType ?? "", bytes.byteLength ?? 0, r2Key).run();
      }
    }
  },

  // Periodic cleanup — deletes expired messages/attachments so storage doesn't grow unbounded.
  async scheduled(_event: ScheduledEvent, env: Env): Promise<void> {
    const now = Date.now();
    const { results: expired } = await env.DB.prepare(
      `SELECT id FROM messages WHERE expires_at <= ?`
    ).bind(now).all<{ id: string }>();

    for (const row of expired ?? []) {
      const { results: atts } = await env.DB.prepare(
        `SELECT r2_key FROM attachments WHERE message_id = ?`
      ).bind(row.id).all<{ r2_key: string }>();
      for (const a of atts ?? []) {
        await env.ATTACHMENTS.delete(a.r2_key);
      }
      await env.DB.prepare(`DELETE FROM attachments WHERE message_id = ?`).bind(row.id).run();
      await env.DB.prepare(`DELETE FROM messages WHERE id = ?`).bind(row.id).run();
    }
  },
};
